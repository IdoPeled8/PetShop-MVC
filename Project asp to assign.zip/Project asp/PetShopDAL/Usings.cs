﻿global using PetShopModels;
global using Microsoft.EntityFrameworkCore;
global using PetShopDAL.Data;
global using Microsoft.AspNetCore.Identity;
global using Microsoft.AspNetCore.Identity.EntityFrameworkCore;