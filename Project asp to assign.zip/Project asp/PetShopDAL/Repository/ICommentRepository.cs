﻿
namespace PetShopDAL.Repository
{
    public interface ICommentRepository
    {
        Task DeleteAsync(int id);

    }
}
