﻿global using System.ComponentModel.DataAnnotations;
