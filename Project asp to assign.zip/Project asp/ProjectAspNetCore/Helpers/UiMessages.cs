﻿namespace ProjectAspNetCore.Helpers
{
    public static class UiMessages
    {
        public static string animalAdded = "animal Added";
        public static string animalUpdated = "animal update success";
        public static string categoryHaveAnimalMsg = "cant remove Category because this category have animals inside";
        public static string categoryAdded = "category Added succeeded";
        public static string categoryRemoved = "category removed succeeded";
        public static string RegisterSucceeded = "your account as been created Succesfully";
        public static string PhotoIsNull = "You need to choose a photo";
        public static string UserNamePasswordWrong = "User Name or Password is wrong";
        public static string CategoryNameExist = "this category name already Exist";

    }
}
