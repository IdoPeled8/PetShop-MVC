﻿global using Microsoft.AspNetCore.Identity;
global using PetShopModels;
global using PetShopDAL.Repository;
global using Microsoft.AspNetCore.Http;
